package com.example.carrotmarket

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.carrotmarket.databinding.FloatingActionButtonBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton

class FloatingActionButtonActivity : AppCompatActivity() {

//    lateinit var binding: FloatingActionButtonBinding
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding = FloatingActionButtonBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        binding.fab.setOnClickListener()
//    }
}