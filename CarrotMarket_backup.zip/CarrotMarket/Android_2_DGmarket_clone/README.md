# Android_2_DGmarket_clone
안드로이드 2조 당근마켓 클론코딩 미션을 위한 레포지토리입니다.

원본레포지토리에 본인의 브랜치를 만든 후 Fork해서 작업하면 됩니다.
이미 작업중인 안드로이드 프로젝트를 Fork, Clone한 로컬 디렉토리 안으로 이동시켜주세요

자세한 내용은 아래 미션 제출방법 참고해주시면 됩니다.  

https://iron-tumbleweed-cb2.notion.site/5b62ca60b7b64c64a736aca823c0fe18?pvs=4
